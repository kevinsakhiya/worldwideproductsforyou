<?php

include "header.php";

?>
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">food products</h1>
			</div>
			<!--<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">import</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">food & beverage</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>-->
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Export area  ==
	====================================== -->
	<section class="export">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>food & beverage</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div class="export_item">
						<img src="images/export1.png" alt="export">
						<h2>Water Name</h2>
						<div class="export_desc">
							<p>Duis autem vel eum iriure dolor in drerit in vulputate velit essc.</p>
						</div>
					</div>
				</div>
				
			<!--<div class="row">
				<div class="pagination_list">
					<ul>
						<li><a href="#"><i class="icon ion-arrow-left-b"></i></a></li>		
						<li><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#"><i class="ion-arrow-right-c"></i></a></li>
					</ul>
				</div>
			</div>-->
		</div>
	</section>
	<!-- ======================================
	        ==   End Export area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	<footer>
		<section class="contact_area">
			<div class="container">
				<div class="row">
					<div class="contact_box">
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Emergency Contact</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-android-call"></i>
									</div>
									<div class="contact_info">
										<a href="#">+001 (1234) 5647</a>								
										<a href="#">+001 (1234) 5647</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Location</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-location-outline"></i>
									</div>
									<div class="contact_info">
										<p>203, Envato Labs, Behind Alis Steet,Melbourne, Australia.</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Emergency Contact</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-email-outline"></i>
									</div>
									<div class="contact_info">
										<a href="mailto:infonews@gmail.com">infonews@gmail.com</a>
										<a href="mailto:youremailname.net?subject=feedback">youremailname.net</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- footer top -->
		<div class="footer_top">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="footer_logo wow slideInLeft" >
							<div class="footer_logo_image">
								<a href="index.html"><img src="images/logo.png" alt="logo"></a>
							</div>
							<div class="footer_logo_info">
								<p>Duis autem vel eum iriure dolor in hendr vulputatec velit esse molestie consequat vel illum dolofeu nulla facilisis at vero eros et accumsan et iusto dignissim qui blandit praesent luptatum zzril delenit .</p>
							</div>						
							<div class="social_media">					
								<ul>
									<li>
										<a href="#">
											<i class="ion-social-facebook"></i>
											<i class="ion-social-facebook hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-twitter"></i>
											<i class="ion-social-twitter hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-instagram"></i>
											<i class="ion-social-instagram-outline hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-skype"></i>
											<i class="ion-social-skype-outline hover_effect"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>					
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="footer_list_link wow slideInLeft" >
							<div class="widget_title">
								<h1>quick link</h1>
							</div>
							<div class="links">
								<ul>
									<li><a href="index.html"><i class="ion-arrow-right-c"></i>Home</a></li>
									<li><a href="about_us.html"><i class="ion-arrow-right-c"></i>About Us</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Services</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Latest Work</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Our Partners</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Testimonials</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Latest News</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="footer_newsletter wow slideInRight">
							<div class="widget_title">
								<h1>News Subscription</h1>
							</div>
							<div class="subscribe_info">
								<p>Subscribe to our newsletter to get all our news in your inbox.</p>
							</div>
							<div class="subscribe_form">
								<form action="#" method="post">
									<input type="email" class="subscribe" placeholder="Enter your email address">
									<button class="btn_subscribe btn3">subscribe</button>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4">
						<div class="footer_insta wow slideInRight">
							<div class="widget_title">
								<h1>instagram</h1>
							</div>
							<div class="insta_pictures">
								<ul>
									<li>
										<img src="images/insta1.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta2.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta3.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta4.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta5.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta6.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- footer bootom -->
		<div class="footer_bottom">		
			<div class="container">
				<div class="copyright">
				<p data-hover="Copyright © 2017, Design  by ThemeeBiT">Copyright © 2017, Design  by ThemeeBiT</p>
			</div>					
			<div class="scroll btn2">
				<i class="ion-arrow-up-c"></i>
			</div>
			</div>					
		</div>
	</footer>
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>