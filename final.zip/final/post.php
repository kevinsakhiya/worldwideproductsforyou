<?php
session_start();


if(isset($_SESSION['user_email'])){
	include "header.php";
include "connect.php";
    $email = $_SESSION['user_email'];
    $proid = $_GET['proid'];
    $q = "select * from products where id='$proid'";
    $r = mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            $img = 'products/'.$row['image'];
			$rs = $row['rs'];
			$pid = $row['id'];
        }
    }

    $q = "select * from user_register where user_email='$email'";
    $r = mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            $fname = $row['user_fname'];
            $lname=$row['user_lname'];
            $contact = $row['user_contact'];
        }
    }

	$_SESSION['rs'] = $rs;
?>
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">Post</h1>
			</div>
			
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Log in  area  ==

	====================================== -->

	<script>
	function calc() 
	{
  	var price = "<?php echo $rs; ?>";
  	var noTickets = document.getElementById("quantity").value;
  	var total = parseFloat(price) * noTickets
  	if (!isNaN(total))
    document.getElementById("total").innerHTML = total
	}
	
	</script>
	<section class="log_in_form">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-offset-1 col-sm-6">
					<div class="login_form wow slideInLeft">
						<h1>Import Or Export Products</h1>
						<form action="post_code.php" method="post">
						<div class="login_name">
								<label for="login_name">
								Product-ID<span></span>
								</label>
								<input type="text" id="login_name" name="pid" value=<?php echo $pid; ?> readonly>
							</div>
                            <div class="login_name">
								<label for="login_name">
								Email<span></span>
								</label>
								<input type="text" id="login_name" name="email" value=<?php echo $email; ?> readonly>
							</div>
							<div class="login_name">
								<label for="login_name">
								 Address<span></span>
								</label>
								<input type="text" id="login_name" name="address" style="height:100px; " required>
							</div>
							<div class="login_name">
								<label for="login_name">
								Contact<span></span>
								</label>
								<input type="text" id="login_name" name="contact" value=<?php echo $contact; ?> required>
							</div>
							
							<div >
								<label for="country">Import or Export</label>
								<div class="select">
									<select name="country" id="country" class="options">
									 	
										<option value="Import">Import</option>
										<option value="Export">Export</option>
										
									</select>
								</div>
							</div>
							<br>
							<div>
								<label for="login_form">Quantity</label>
								<input type="text" id="quantity" name="quantity" value="1" oninput="calc()" style="height: 35px">
								


							</div><br>
							<div class="login_name">
								<label for="login_name">
								Total<span></span>
								</label>
								<span style="font-size:20px">Rs. </span><span style="font-size:20px" id="total"><?php echo $rs; ?></span><span style="font-size:20px">/-</span>
							</div>
							<br>
							
							<br>
							
							
							<button class="btn3">
							Buy Now
						</button>
							
					</div>
				</div>
				<div class="col-md-5 col-sm-6">
					<figure class="log_image wow slideInRight">
                        <img src=<?php echo $img; ?> alt="log in" style="border:5px solid #ddd;border-radius:4px;padding:5px">
                        <h2 style="text-align:center" id="rss">Rs. <?php echo $rs; ?>/-</h2>
                    </figure>
                    
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        ==   End Log in area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	<footer>
		<section class="contact_area">
			<div class="container">
				<div class="row">
					<div class="contact_box">
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Emergency Contact</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-android-call"></i>
									</div>
									<div class="contact_info">
										<a href="#">+001 (1234) 5647</a>								
										<a href="#">+001 (1234) 5647</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Location</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-location-outline"></i>
									</div>
									<div class="contact_info">
										<p>203, Envato Labs, Behind Alis Steet,Melbourne, Australia.</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Emergency Contact</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-email-outline"></i>
									</div>
									<div class="contact_info">
										<a href="mailto:infonews@gmail.com">infonews@gmail.com</a>
										<a href="mailto:youremailname.net?subject=feedback">youremailname.net</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- footer top -->
		<div class="footer_top">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="footer_logo wow slideInLeft" >
							<div class="footer_logo_image">
								<a href="index.html"><img src="images/logo.png" alt="logo"></a>
							</div>
							<div class="footer_logo_info">
								<p>Duis autem vel eum iriure dolor in hendr vulputatec velit esse molestie consequat vel illum dolofeu nulla facilisis at vero eros et accumsan et iusto dignissim qui blandit praesent luptatum zzril delenit .</p>
							</div>						
							<div class="social_media">					
								<ul>
									<li>
										<a href="#">
											<i class="ion-social-facebook"></i>
											<i class="ion-social-facebook hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-twitter"></i>
											<i class="ion-social-twitter hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-instagram"></i>
											<i class="ion-social-instagram-outline hover_effect"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="ion-social-skype"></i>
											<i class="ion-social-skype-outline hover_effect"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>					
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="footer_list_link wow slideInLeft" >
							<div class="widget_title">
								<h1>quick link</h1>
							</div>
							<div class="links">
								<ul>
									<li><a href="index.html"><i class="ion-arrow-right-c"></i>Home</a></li>
									<li><a href="about_us.html"><i class="ion-arrow-right-c"></i>About Us</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Services</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Latest Work</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Our Partners</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Testimonials</a></li>
									<li><a href="#"><i class="ion-arrow-right-c"></i>Latest News</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="footer_newsletter wow slideInRight">
							<div class="widget_title">
								<h1>News Subscription</h1>
							</div>
							<div class="subscribe_info">
								<p>Subscribe to our newsletter to get all our news in your inbox.</p>
							</div>
							<div class="subscribe_form">
								<form action="#" method="post">
									<input type="email" class="subscribe" placeholder="Enter your email address">
									<button class="btn_subscribe btn3">subscribe</button>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4">
						<div class="footer_insta wow slideInRight">
							<div class="widget_title">
								<h1>instagram</h1>
							</div>
							<div class="insta_pictures">
								<ul>
									<li>
										<img src="images/insta1.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta2.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta3.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta4.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta5.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
									<li>
										<img src="images/insta6.png" alt="instagram">
										<div class="insta_hover">
											<a class="ion-android-add" href="#"></a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- footer bootom -->
		<div class="footer_bottom">		
			<div class="container">
				<div class="copyright">
				<p data-hover="Copyright © 2017, Design  by ThemeeBiT">Copyright © 2017, Design  by ThemeeBiT</p>
			</div>					
			<div class="scroll btn2">
				<i class="ion-arrow-up-c"></i>
			</div>
			</div>					
		</div>
	</footer>
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

}
else{
    $_SESSION['post_msg'] = "0";
    header('Location:login.php');
}


?>