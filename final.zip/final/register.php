<?php

include "header.php";

if(isset($_SESSION['register_msg'])){
if($_SESSION['register_msg'] == "0"){
	echo "<script type='text/javascript'>alert('User already exist');</script>";
	unset($_SESSION['register_msg']);
}
}
?>
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">Register</h1>
			</div>
			<!--<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="index.html">Pages</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">Register</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>-->
			</div>
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Register  area  ==
	====================================== -->
	<section class="register">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<form action="register_code.php" method="post" enctype="multipart/form-data">
						<div class="reg_form">
							<div class="register_title">
								<h1>Welcome to Buyers.com</h1>
								<p>Join as a Free Member to get more update. It’s very easy & free.</p>
							</div>
							<div class="reg_form_title">
								<h1>Create a New  Account</h1>
                            </div>
							<div class="name input_cmn">
								<label for="user_image">User Image*</label>
								<input type="file" id="user_image" name="user_image" required>
							</div><br><br>
							<div class="name input_cmn">
								<label for="frst_name">First Name*</label>
								<input type="text" id="frst_name" name="first_name" title="Alphabets allowed only" required>
							</div>
							<div class="name input_cmn input_lst_style">
								<label for="lst_name">Last Name*</label>
								<input type="text" id="lst_name" name="last_name" title="Alphabets allowed only" required>
							</div>
							<div class="bsn_radio">
								<label>I am a</label>
								<div class="rd_btn">
									<input type="radio" name="gender" value="Male" checked class="dsgn">Male
								</div>
								<div class="rd_btn">
									<input type="radio" name="gender" value="Female" class="dsgn">Female
								</div>
								<div class="rd_btn">
									<input type="radio" name="gender" value="Other" class="dsgn">Other
								</div>
							</div>
							<div class="reg_email">
								<label for="user_contact">Enter your contact no.*</label>
								<input type="text" id="user_contact" name="user_contact" required maxlength="10">
							</div>
							
							<div class="reg_email">
								<label for="regs_email">Enter your Country*</label>
								<input type="text" id="user_country" name="user_country" required>
							</div>
							<div class="reg_email">
								<label for="regs_email">Enter your Country code*</label>
								<input type="text" id="user_country_code" name="user_country_code" required>
							</div>
							<div class="name input_cmn">
								<label for="user_image">Brand Image*</label>
								<input type="file" id="brand_image" name="brand_image" required>
							</div><br><br>
							<div class="reg_password">
								<label for="regs_pwd">Brand Name*</label>
								<input type="text" id="brand_name" name ="brand_name" required>
                            </div>
							<div class="reg_email">
								<label for="regs_email">Enter your email*</label>
								<input type="email" id="user_email" name="user_email" required>
							</div>
							<div class="reg_password">
								<label for="regs_pwd">Enter your password*</label>
								<input type="password" id="user_pwd" name ="user_pwd" required>
                            </div>
                           
							<div class="btn_check">
								<button class="btn3" name="submit" type="submit">sign in</button>
								
							</div>
							<!--<div class="click_list">
								<a href="#">Forgot password ?<span>Click Here</span></a>
							</div>-->							
						</div>
						<!--<div class="bsn_form">
							<div class="bsn_title">
								<h1>Enter Your Business Information</h1>
							</div>
							<div class="bsn_radio">
								<label>I am a</label>
								<div class="rd_btn">
									<input type="radio" name="designation" value="buyer" checked class="dsgn">Buyer
								</div>
								<div class="rd_btn">
									<input type="radio" name="designation" value="seller" class="dsgn">Supplier
								</div>
								<div class="rd_btn">
									<input type="radio" name="designation" value="both" class="dsgn">Both
								</div>
							</div>
							<div class="bsn_frm_input input_cmn ">
								<label for="country">add your country</label>
								<div class="select">
									<select name="country" id="country" class="options">
									 	<option value="" disabled selected>Select Your Country</option>
										<option value="Bangladesh">Bangladesh</option>
										<option value="India">India</option>
										<option value="Nepal">Nepal</option>
										<option value="Bhutan">Bhutan</option>
									</select>
								</div>
							</div>
							<div class="bsn_frm_input input_cmn input_lst_style">
								<label for="country_code">country code</label>
								<input type="text" id="country_code" placeholder="Type here">
							</div>
							<div class="bsn_frm_input input_cmn">
								<label for="company">company name</label>
								<input type="text" id="company" placeholder="Your Company">
							</div>
							<div class="bsn_frm_input input_cmn input_lst_style">
								<label for="company_type">company type</label>
								<div class="select">
									<select name="company_type" id="company_type" class="options">
									 	<option value="" disabled selected>Company Type</option>
										<option value="Bangladesh">Tech</option>
										<option value="India">Education</option>
										<option value="Nepal">Business</option>
										<option value="Bhutan">Services</option>
									</select>								
								</div>
							</div>
							<div class="bsn_frm_input input_cmn">
								<label for="cc">country code</label>
								<input type="text" id="cc" placeholder="Contact no">
							</div>
							<div class="bsn_frm_input input_cmn input_lst_style">
								<label for="office_contact">Office contact no</label>
								<input type="text" id="office_contact" placeholder="Contact no">
							</div>
							<div class="agree_check">
								<input type="checkbox"  id="agree_check" >
								<label for="agree_check">I agree with the buyers.com.<a href="#">Terms and services</a></label>
							</div>
							<div class="notification_check">
								<input type="checkbox"  id="notification_check">
								<label for="notification_check">I would like to recieve information related to my industry and service notification letters from buyers.com</label>
							</div>
							<div class="captcha">
								<img src="images/captcha.png" alt="captcha">
							</div>
							<button class="btn_style btn3">create account</button>
						</div>-->
					</form>
				</div>
				<!--<div class="col-md-6">
					<figure class="register_image">
						<img src="images/Register.png" alt="register">
					</figure>
				</div>-->
			</div>
		</div>
	</section>
	<!-- ======================================
	        ==   End Register  area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

include "footer.php";

?>