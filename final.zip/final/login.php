<?php

include "header.php";

if(isset($_SESSION['login_msg'])){
if($_SESSION['login_msg'] == "0"){
    echo "<script type='text/javascript'>alert('Username or password incorrect');</script>";
	unset($_SESSION['login_msg']);
}
}
if(isset($_SESSION['post_msg'])){
	if($_SESSION['post_msg'] == "0"){
		echo "<script type='text/javascript'>alert('Please login first');</script>";
		unset($_SESSION['post_msg']);
	}
	}
?>
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">log in</h1>
			</div>
			<!--<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="index.html">Pages</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">Log In</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>-->
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Log in  area  ==
	====================================== -->
	<section class="log_in_form">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-offset-1 col-sm-6">
					<div class="login_form wow slideInLeft">
						<h1>Sign In To Your Account</h1>
						<form action="login_code.php" method="post">
							<div class="login_name">
								<label for="login_name">
								Enter your email name<span>*</span>
								</label>
								<input type="text" id="login_name" name="login_name" required>
							</div>
							<div class="login_pwd">
								<label for="login_password">
								Enter your password<span>*</span>
								</label>
								<input type="password" id="login_password" name="login_password" required>
							</div>
							<button class="btn3">log in</button>
							<!--<div class="login_check">
								<input type="checkbox" name="remember" value="Remember Me" id="login_check" >
							 	<label for="login_check">Remember Me</label>
							</div>-->
						</form>
						<div class="click_list">
						<!--	<a href="#">Forgot password ?<span> Click Here</span></a>-->
							<a href="register.php">New User ?<span> Register Now</span></a>
						</div>
					</div>
				</div>
				<div class="col-md-5 col-sm-6">
					<figure class="log_image wow slideInRight">
						<img src="images/login.png" alt="log in">
					</figure>
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        ==   End Log in area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

include "footer.php";

?>