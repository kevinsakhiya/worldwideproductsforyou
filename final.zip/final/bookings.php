<?php
session_start();
if(isset($_SESSION['user_email'])){
    
    include "header.php";
    
    include "connect.php";
    $email = $_SESSION['user_email'];
        
?>

<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">My Bookings</h1>
			</div>
			<!--<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">import</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">food & beverage</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>-->
		</div>	
    </section>
    <section class="export">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<!--<h1>Products</h1>-->
					</div>
				</div>
            </div>
    
	<table id="t01">
        <tr>
            <th>Product Name</th>
            <th>Amount</th>
            <th>Quantity</th>
            <th>Address</th>
            <th>Contact No.</th>
            <th>Import/Export</th>
            <th>Total</th>
        </tr>
        <?php
    
    $q="select * from buy where email='$email'";
    $r=mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
           $pid = $row['pid'];
           $address=$row['address'];
           $contact=$row['contact'];
           $type = $row['type'];
           $quantity = $row['quantity'];
           $rs=$row['rs'];
           $total=$row['total'];
            $qu = "select * from products where id='$pid'";
           $re = mysqli_query($cn,$qu);
           if(mysqli_num_rows($re)>0)
	        {
		        while($row2=mysqli_fetch_array($re))
		        {
                    $pname = $row2['name'];
                    $sub = $row2['subid'];
                    $url='products3.php?sub='.$sub;
    
    ?>
        <tr>
            <td><a href=<?php echo $url; ?>><u><?php echo $pname; ?></u></a></td>
            <td><?php echo $rs; ?></td>
            <td><?php echo $quantity; ?></td>
            <td><?php echo $address; ?></td>
            <td><?php echo $contact; ?></td>
            <td><?php echo $type; ?></td>
            <td><?php echo $total; ?></td>
        </tr>
        <?php
    
                }}}}
    ?>
    </table>
    </div>
	</section>

<?php

include "footer.php";
      
            
}
            else{
                $_SESSION['post_msg'] = "0";
                header('Location:login.php');
            }
?>