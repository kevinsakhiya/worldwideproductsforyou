<?php


	

include "connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Title-->
	<title>International Buyer HTML5 Template</title>

	<!--Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,700i,900" rel="stylesheet">
	<link rel="stylesheet" href="css/lato.css">

	<!-- Favicon  -->
	<link rel="apple-touch-icon-precomposed" href="images/favicon.png">
	<link rel="shortcut icon" href="images/favicon.png" type="image/png">
    <link rel="icon" href="images/favicon.png" type="image/png">

	<!-- Bootstrap -->	
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Animate -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">

	<!-- Venobox -->
	<link rel="stylesheet" href="css/venobox.css">

	<!-- Ionicons -->
	<link rel="stylesheet" href="css/ionicons.min.css">

	<!-- Mean menu css -->
	<link rel="stylesheet" href="css/meanmenu.min.css">

	<!-- Main style sheet -->
	<link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>

	<style>
		table {
		margin-left:50px;
		margin-top:50px;
		margin-botttom:50px;
		width:80%;
		}
		th, td {
  padding: 15px;
  text-align: left;
}
		table#t01 tr:nth-child(even) {
 		 background-color: #eee;
		  padding:20px;	
		}
		table#t01 tr:nth-child(odd) {
 			background-color: #fff;
			 padding:20px;
		}
		table#t01 th {
  			background-color: black;
  			color: white;
			  padding:20px;
		}
	</style>



</head>
<body>
	<!-- ======================================
	        ==   Start Header area  ==
	====================================== -->
	<header>
		<div class="header_top">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<div class="toolbar">
							<ul class="header_menu">
								<!--<li>
									<a href="#"><i class="ion-flash active"></i>English<i class="ion-chevron-down icon_down"></i></a>
									<ul class=lang_menu>				
										<li>French</li>
										<li>German</li>
										<li>Chinese</li>
									</ul>
								</li>-->
								<?php
									if(isset($_SESSION['user_email'])){
										$email = $_SESSION['user_email'];
										$q="select * from user_register where user_email='$email'";
										$r=mysqli_query($cn,$q);
										$arr=mysqli_fetch_array($r);

										$contact= $arr['user_contact'];

								?>
								<li><a href="tel:+001(1234)6457"><i class="ion-android-call active"></i><?php echo $contact; ?></a></li>
								<li><a href="mailto:youremail@gmail.com"><i class="ion-email"></i><?php echo $email; ?></a></li>
								<li><a href="logout.php"><i class="ion-email"></i><u>Logout</u></a></li>
								<?php
									}
										
								?>

							</ul>
						</div>
					</div>
					<?php
					
					if(!isset($_SESSION['user_email'])){
					
					?>
					<div class="col-sm-4">
						<div class="log_in">
							<div class="log_in_info">
								<a href="login.php"><i class="ion-unlocked"></i>Log In </a>		
                            </div>
                            <div class="log_in_info">
								<a href="register.php"><i class="ion-unlocked"></i>Register </a>		
							</div>
						</div>
                    </div>
					<?php
					}
					?>			
				</div>
			</div>
		</div>
		
		<div class="header_bottom">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="header_logo">
							<a href="index.php"><img src="images/headerlogo.png" alt="logo"></a>
						</div>
					</div>
					<div class="col-sm-10">
						<div class="main_nav">
							<nav class="header_nav">
								<ul class="main_menu">
									<li>
										<a href="index.php">Home</a>
										<ul class="homes">
											
											
										</ul>
									</li>
									<li><a href="about_us.php">About</a></li>
									<li><a href="products.php">Products</a></li>
									<li><a href="bookings.php">My Bookings</a></li>
									<li><a href="contact.php">Contact</a></li>

								</ul>
							</nav>
							
							
						</div>
					</div>				
				</div>			
			</div>		
		</div>
		<div class="mobile_menu">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="mobile_mean_logo">
							<a href="index.php">
								<img src="images/logo.png" alt="logo">
							</a>
						</div>
						<div class="mobile_mean_menu">
							
								<ul>
								<li>
									<a href="about_us.php">About</a>
								</li>
								<li>
									<a href="products.php">Products</a>
								</li>
								<li><a href="bookings.php">My Bookings</a></li>
								<li>
									<a href="contact.php">Contact</a>
								</li>
								
						
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</header>