<?php

include "header.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Title-->
	<title>International Buyer HTML5 Template</title>

	<!--Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,700i,900" rel="stylesheet">
	<link rel="stylesheet" href="css/lato.css">

	<!-- Favicon  -->
	<link rel="apple-touch-icon-precomposed" href="images/favicon.png">
	<link rel="shortcut icon" href="images/favicon.png" type="image/png">
    <link rel="icon" href="images/favicon.png" type="image/png">

	<!-- Bootstrap -->	
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Animate -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">

	<!-- Venobox -->
	<link rel="stylesheet" href="css/venobox.css">

	<!-- Ionicons -->
	<link rel="stylesheet" href="css/ionicons.min.css">

	<!-- Mean menu css -->
	<link rel="stylesheet" href="css/meanmenu.min.css">

	<!-- Main style sheet -->
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<!-- ======================================
	        ==   Start Header area  ==
	====================================== -->
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">About us</h1>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">About Us</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start About us area  ==
	====================================== -->
	<section class="about_info">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<aside class="about_list">
						<ul>
							<li class="active"><a href="#wdo" data-list="What I Do" data-toggle="tab">What I Do</a></li>		
							<li><a href="#mission" data-list="my mission"  data-toggle="tab">my mission</a></li>
							<li><a href="#vission" data-list="my vission" data-toggle="tab">my vission</a></li>
							<li><a href="#goal" data-list="my goal" data-toggle="tab">my goal</a></li>
						</ul>
					</aside>
				</div>
				<div class="col-sm-9">
					<div class="tab-content">
						<div class="tab-pane fade-in active" id="wdo">
							<div class="single_tab">
								<figure class="single_tab_image">
									<img src="images/About-us.png" alt="About Us">
								</figure>
								<article class="single_tab_txt">
									<h2>What is import export business?</h2>
									<p>The Export/Import business is primarily an expansion of trade boundaries wherein several business models exist. Just like the conventional business, a person with the requisite Export/Import license can sell his manufactured goods to clients abroad, can act as an intermediary between the local manufacture and overseas buyer or vice versa, and can be directly purchasing good produced abroad and selling them in the native market. The export-import business becomes unique with the involvement of various stakeholders and risks, which do not come into picture with domestic trade.</p>
								</article>
							</div>
						</div>
						<div class="tab-pane fade" id="mission">
							<div class="single_tab">
								<figure class="single_tab_image">
									<img src="images/us2.jpg" alt="About Us">
								</figure>
								<article class="single_tab_txt">
									<h2>MY Mission</h2>
									<p>Trade mission is an international trip by government officials and businesspeople that is organized by agencies of national or provincial governments for purpose of exploring international business opportunities. Business people who attend trade missions are typically introduced both to important business contacts and to well-placed government officials. A trade mission is a way in which countries or organizations can seek out potential buyers and sellers. Trade missions will usually occur after one party has undergone significant market research. In short, trade mission is a trip that is designed to transport business executives into a foreign business environment to achieve International business relationship </p>
								</article>
							</div>
						</div>
						<div class="tab-pane fade" id="vission">
							<div class="single_tab">
								<figure class="single_tab_image">
									<img src="images/mission.jpg" alt="About Us">
								</figure>
								<article class="single_tab_txt">
									<h2>My Vision</h2>
									<p>"Imports" consist of transactions in goods and services to a resident of a jurisdiction (such as a nation) from non-residents.[4] The exact definition of imports in national accounts includes and excludes specific "borderline" cases.[5]. Importation is the action of buying or acquiring products or services from another country or another market other than own. Imports are important for the economy because they allow a country to supply nonexistent, scarce, high cost or low quality of certain products or services, to its market with products from other countries.</p>
								</article>
							</div>
						</div>
						<div class="tab-pane fade" id="goal">
							<div class="single_tab">
								<figure class="single_tab_image">
									<img src="images/goal.jpg" alt="About Us">
								</figure>
								<article class="single_tab_txt">
									<h2>My Goal</h2>
									<p>An import is a good or service brought into one country from another country as well as export; which is the process of taking product from one country to another country. The backbone of international trade is specially formed around the term import and export; because the act of international exchange of goods is a significant part of international trading. It is very necessary to balance the value of trading between importation and the amount of product leaving the country so that the host country will have a positive trade balance; else there will be negative balance of trade; which is a critical factor of economy growth and development.</p>
								</article>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        ==   End About us area  ==
	====================================== -->
	<!-- ======================================
	        ==  Start What I do area  ==
	====================================== -->
	<section class="about_us do">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>what  i  do</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-4 ">
					<div class="services">
						<div class="service_area1  wow rotateInDownRight">
							<div class="single_services">
								<div class="service_info">
									<h2>Import</h2>
									<p>An import is a good or service bought in one country that was produced in another.</p>
								</div>
								<div class="service_image">
									<img src="images/import.png" alt="import" class="svg">
								</div>
							</div>
							<div class="single_services">
								<div class="service_info">
									<h2>Export</h2>
									<p>An export in international trade is a good or service produced in one country that is sold into another country. </p>
								</div>
								<div class="service_image">
									<img src="images/export.png" alt="export" class="svg">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-sm-offset-4 ">
					<div class="services">
						<div class="service_area2 wow rotateInDownLeft">
							<div class="single_services current_page_item">
								<div class="service_image">
										<img src="images/buy.png" alt="cart" class="svg">
									</div>
								<div class="service_info">
									<h2>buy</h2>
									<p>to acquire the possession of, or the right to, by paying or promising to pay an equivalent.</p>
								</div>							
							</div>
							<div class="single_services">
								<div class="service_image">
										<img src="images/sales.png" alt="sales" class="svg">
									</div>
								<div class="service_info">
									<h2>sales</h2>
									<p>Sales are activities related to selling or the number of goods or services sold in a given targeted time period.</p>
								</div>							
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        == End What I do area  ==
	====================================== -->
	<!-- ======================================
	        == Start Trusted Partners area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Trusted Partners area  ==
	====================================== -->
	<!-- ======================================
	        == Start Feedback area  ==
	====================================== -->
	<section class=" about_us feedback">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>our buyer/supplier feedback</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="feedback_slider owl-carousel">
						<div class="single_feedback">
							<div class="feedback_info">
								<blockquote>
									Duis autem vel eum iriure dolor in hendrerit in vultate velit esse molestie consequat vel illum dolore eu fgiat nulla facilisis at vero eros et accumsan et iusto.
								</blockquote>
								<p>Md. Masud , DIT  Manager</p>
							</div>
							<div class="feed_image">
								<img src="images/feedback1.png" alt="feedback" class="feedback_image">
							</div>
						</div>
						<div class="single_feedback">
							<div class="feedback_info">
								<blockquote>
								Duis autem vel eum iriure dolor in hendrerit in vultate velit esse molestie consequat vel illum dolore eu fgiat nulla facilisis at vero eros et accumsan et iusto.
								</blockquote>
								<p>Keith Hawkins , DIT  Manager</p>
							</div>
							<div class="feed_image">
								<img src="images/feedback2.png" alt="feedback" class="feedback_image">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>
	<!-- ======================================
	        == End Feedback area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

include "footer.php";

?>