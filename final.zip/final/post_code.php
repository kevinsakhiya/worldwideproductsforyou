<?php

session_start();
include "connect.php";

$email = $_POST['email'];
$address = $_POST['address'];
$contact = $_POST['contact'];
$country = $_POST['country'];
$quantity = $_POST['quantity'];
$pid=$_POST['pid'];
$rs = $_SESSION['rs'];
$total = $quantity*$rs;
unset($_SESSION['rs']);

$q = "insert into buy values(null,'$pid','$email','$address','$contact','$country','$quantity','$rs','$total')";
$r = mysqli_query($cn,$q);

if($r){
    echo "Success";
}else{
    echo "Not Success";
}

?>