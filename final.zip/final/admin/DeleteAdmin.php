<?php

include "connect.php";
$cat = $_GET['aid'];

$q = "delete from admin where id='$cat'";
$r = mysqli_query($cn,$q);

if($r){
    header('Location:admin.php');
}
else{
    echo "Admin is not deleted";
}

?>