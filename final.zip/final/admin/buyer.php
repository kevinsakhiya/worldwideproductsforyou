<?php

include "header.php";
include "connect.php";
$count = 0;
?>

<!-- /inner_content-->
<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						<div class="w3l_agileits_breadcrumbs">
							<div class="w3l_agileits_breadcrumbs_inner">
								<ul>
									<li><a href="main-page.html">Home</a><span>«</span></li>
									
									<li>Buyer</li>
								</ul>
							</div>
						</div>
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Buyers Detail</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
                                <table id="t01">
                                <tr>
                                            <th>Buyer Email ID</th>
                                            <th>Buyer Profile</th>
											<th>Buyer Name</th>
                                            <th>Buyer Contact</th>
                                            <th>Buyer Address</th>
                                            <th>Product Image</th>
											<th>Product Name</th>
											<th>Product Price</th>
											<th>Quantity</th>
											<th>Import/Export</th>
											<th>Total</th>
                                     
                                 </tr>
									 
									  
										
                                        <?php
                                        
                                        $q="select * from buy";
                                        $r = mysqli_query($cn,$q);
                                        if(mysqli_num_rows($r)>0){
                                            while($row=mysqli_fetch_array($r)){
                                                $pid = $row['pid'];
                                                $email = $row['email'];
                                                $address = $row['address'];
                                                $contact = $row['contact'];
                                                $type = $row['type'];
                                                $quantity = $row['quantity'];
                                                $price = $row['rs'];
                                                $total = $row['total'];
                                                $qin = "select * from user_register where user_email='$email'";
                                                $rin = mysqli_query($cn,$qin);
                                                
                                                if(mysqli_num_rows($rin)>0){
                                                    while($row2=mysqli_fetch_array($rin)){
                                                        $img = "../user/".$row2['user_img'];
                                                        $fname =$row2['user_fname'];
                                                        $lname =$row2['user_lname'];
                                                        $name = $fname."-".$lname;
                                                        $q2 = "select * from products where id ='$pid'";
                                                        $r2 = mysqli_query($cn,$q2);
                                                        if(mysqli_num_rows($r2)>0){
                                                            while($row3=mysqli_fetch_array($r2)){
                                                                $pname = $row3['name'];
                                                                $pimg = "../products/".$row3['image'];
                                        
                                        ?>
                                        
											<tr>
                                                <td><?php echo $email; ?></td>
                                                <td><img src=<?php echo $img; ?> style="border-radius:50%;width:100px;height:100px"></td>
                                                <td><?php echo $name; ?></td>
                                                <td><?php echo $contact; ?></td>
                                                <td><?php echo $address; ?></td>
                                                <td><img src=<?php echo $pimg; ?>></td>
                                                <td><?php echo $pname; ?></td>               
                                                <td><?php echo $price; ?></td>
                                                <td><?php echo $quantity; ?></td>
                                                <td><?php echo $type; ?></td>
                                                <td><?php echo $total; ?></td>
                                              </tr>
                                              <?php
                                              
                                                            }
                                                        }
                                                    }
                                                }
                                                $count = $count + $total;
                                            }
                                        }
                                              
                                              
                                              ?>
										<tr><td colspan='11'><span style="font-size:30px">Total  Profit  : <?php echo $count; ?></span></td></tr>
									  </table>

								
									</div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->

<?php

include "footer.php";

?>