<?php

include "connect.php";
$cat = $_GET['cat'];

$q1 = "select * from subcategory where catid='$cat'";
$r1 = mysqli_query($cn,$q1);
if(mysqli_num_rows($r1)>0)
	{
		while($row=mysqli_fetch_array($r1))
		{
            $subid = $row['sub_id'];
            ///////// Delete product ////////////////////
           $q2 = "select * from products where subid='$subid'";
           $r2 = mysqli_query($cn,$q2);
           if(mysqli_num_rows($r2)>0)
	        {
		        while($row2=mysqli_fetch_array($r2))
		        {
                    $pid = $row2['id'];
                    $image = "../products/".$row2['image'];
                    unlink($image);
                    $ii = "delete from products where id='$pid'";
                    $rr = mysqli_query($cn,$ii);
                }
            }
             ///////Delete subcategory/////////////////////
             
             $image = "../subcategory/".$row['subimg'];
             unlink($image);
             $inq = "delete from subcategory where sub_id='$subid'";
             $inr = mysqli_query($cn,$inq);
        }
    }


$t = "select * from category where cat_id='$cat'";
$y = mysqli_query($cn,$t);
if(mysqli_num_rows($y)>0)
	{
		while($row=mysqli_fetch_array($y))
		{
            $image = "../category/".$row['catimg'];
            unlink($image);
        }
    }

$q = "delete from category where cat_id='$cat'";
$r = mysqli_query($cn,$q);

if($r){
    header('Location:addProduct.php');
}
else{
    echo "File is not deleted";
}

?>