<?php

include "header.php";
include "connect.php";
$subid = $_GET['subid'];
?>




		
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						<div class="w3l_agileits_breadcrumbs">
							<div class="w3l_agileits_breadcrumbs_inner">
								<ul>
									<li><a href="index.php">Home</a><span>«</span></li>
									
									<li>Add Products</li>
								</ul>
							</div>
						</div>
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Add Products</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
								<h3 class="w3_inner_tittle two">Add New Product </h3>  
								<div class="form-body">
										<form action="addProduct_code.php" method="post" enctype="multipart/form-data"> 
                                        <div class="form-group">
												
												<input type="text" class="form-control"  value=<?php echo $subid; ?> name="sub" readonly> 
											</div>    
                                        <div class="form-group">
												<label for="exampleInputEmail1">Product Name</label> 
												<input type="text" class="form-control"  placeholder="Product Name" name="product"> 
											</div>
											 
											 <div class="form-group">
											  <label for="exampleInputFile">Choose Image</label> 
											  <input type="file" id="InputFile" name="InputFile"> 
											  
											  	
                                              </div> 
                                              <div class="form-group">
												<label for="exampleInputEmail1">Amount</label> 
												<input type="text" class="form-control"  placeholder="Amount" name="amount"> 
											</div>
											  <button type="submit" name="submit" class="btn btn-default">Submit</button> 
										</form> 
											</div>
                                <table id="t01">
        <tr>
            <th>Product  ID</th>
            <th>Product Name</th>
            <th>Product Image</th>
            <th>Product Amount</th>
            <th></th>
            <th></th>
        </tr>
        <?php
    
    $q="select * from products where subid='$subid'";
    $r=mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            $deleteURL = "deleteProduct.php?pid=".$row['id'];
            $img = "../products/".$row['image'];
            $updateURL = "updateProduct.php?pid=".$row['id'];
        ?>
       <tr>
        
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><img src=<?php echo $img; ?> height=100px width=100px></td>
            <td><?php echo $row['rs']; ?></td>
           <td><a href=<?php echo $updateURL; ?>><i class="fa fa-edit" style="font-size:24px"></i></a></td>
           <td><a href=<?php echo $deleteURL; ?>><i class="fa fa-trash-o" style="font-size:24px;color:red"></i></a></td>
        </tr>
        <?php
        }}
        ?>
        
    </table>

								
									</div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->


<?php

include "footer.php";
?>