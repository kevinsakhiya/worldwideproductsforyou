<?php

include "header.php";
include "connect.php";
?>




		
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						<div class="w3l_agileits_breadcrumbs">
							<div class="w3l_agileits_breadcrumbs_inner">
								<ul>
									<li><a href="index.php">Home</a><span>«</span></li>
									
									<li>Add Products</li>
								</ul>
							</div>
						</div>
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Add Products</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
								<h3 class="w3_inner_tittle two">Add New Category </h3>  
								<div class="form-body">
										<form action="addCategory_code.php" method="post" enctype="multipart/form-data"> 
											<div class="form-group">
												<label for="exampleInputEmail1">Category Name</label> 
												<input type="text" class="form-control"  placeholder="Category Name" name="cat"> 
											</div>
											 
											 <div class="form-group">
											  <label for="exampleInputFile">Choose Image</label> 
											  <input type="file" id="InputFile" name="InputFile"> 
											  
											  	
											  </div> 
											  <button type="submit" name="submit" class="btn btn-default">Submit</button> 
										</form> 
											</div>
                                <table id="t01">
        <tr>
            <th>Category  ID</th>
            <th>Category Name</th>
            <th>Category Image</th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
        <?php
    
    $q="select * from category";
    $r=mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            $updateURL = "updateCat.php?cat=".$row['cat_id'];
            $deleteURL = "DeleteCat.php?cat=".$row['cat_id'];
            $url="sub.php?catid=".$row['cat_id'];
            $img = "../category/".$row['catimg'];
        ?>
       <tr>
        
            <td><?php echo $row['cat_id']; ?></td>
            <td><?php echo $row['catname']; ?></td>
            <td><img src=<?php echo $img; ?> height=100px width=100px></td>
            <td><a href=<?php echo $updateURL; ?>><i class="fa fa-edit" style="font-size:24px"></i></a></td>
            <td><a href=<?php echo $deleteURL; ?>><i class="fa fa-trash-o" style="font-size:24px;color:red"></i></a></td>
            <td> <a href=<?php echo $url; ?>> >> GO </a> </td>
            
        </tr>
        <?php
        }}
        ?>
        
    </table>

								
									</div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->


<?php

include "footer.php";
?>