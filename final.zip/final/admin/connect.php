<?php

$cn=mysqli_connect("localhost","root","","test");

?>