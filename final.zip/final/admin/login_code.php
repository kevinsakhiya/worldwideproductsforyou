<?php

session_start();
include "connect.php";

$email = $_POST['email'];
$password = $_POST['password'];

$q = "select * from admin where unm='$email' and pwd='$password'";
$r = mysqli_query($cn,$q);
$count = mysqli_num_rows($r);

if($count > 0){
    $_SESSION['admin_email'] = $email;
    header('Location:index.php');
   
}
else{
    $_SESSION['admin_msg'] = "0";
    header('Location:login.php');
    
}

?>