<?php

include "header.php";

?>
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->
					<div class="inner_content_w3_agile_info">
					<!-- /agile_top_w3_grids-->
					   <div class="agile_top_w3_grids">
					          <ul class="ca-menu">
									<li>
										<a href="addProduct.php">
											
											<i class="fa fa-plus" aria-hidden="true"></i>
											<div class="ca-content">
												
												<h3 class="ca-sub">Add Products</h3>
											</div>
										</a>
                                    </li>
                                    <li>
										<a href="buyer.php">
											<i class="fa fa-shopping-cart" aria-hidden="true"></i>
											<div class="ca-content">
											<!--<h4 class="ca-main two">29,008</h4>-->
												<h3 class="ca-sub two">Buyers</h3>
											</div>
										</a>
									</li>
									
								
										
									<div class="clearfix"></div>
								</ul>
					   </div>
			
						</div>
						
							
									 <div class="clearfix"></div>
							</div>

							  
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->
	</div>
<!-- banner -->
<?php

include "footer.php";

?>