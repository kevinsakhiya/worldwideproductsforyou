<?php

include "header.php";
include "connect.php";
$catid = $_GET['catid'];
?>




		
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						<div class="w3l_agileits_breadcrumbs">
							<div class="w3l_agileits_breadcrumbs_inner">
								<ul>
									<li><a href="index.php">Home</a><span>«</span></li>
									
									<li>Add Products</li>
								</ul>
							</div>
						</div>
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Add Products</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
								<h3 class="w3_inner_tittle two">Add New sub-Category </h3>  
								<div class="form-body">
										<form action="addsub-category_code.php" method="post" enctype="multipart/form-data"> 
                                        <div class="form-group">
												
												<input type="text" class="form-control"  value=<?php echo $catid?> name="cat" readonly> 
											</div>    
                                        <div class="form-group">
												<label for="exampleInputEmail1">Sub-Category Name</label> 
												<input type="text" class="form-control"  placeholder="Sub-Category Name" name="subcat"> 
											</div>
											 
											 <div class="form-group">
											  <label for="exampleInputFile">Choose Image</label> 
											  <input type="file" id="InputFile" name="InputFile"> 
											  
											  	
											  </div> 
											  <button type="submit" name="submit" class="btn btn-default">Submit</button> 
										</form> 
											</div>
                                <table id="t01">
        <tr>
            <th>Sub-Category  ID</th>
            <th>Sub-Category Name</th>
            <th>Sub-Category Image</th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
        <?php
    
    $q="select * from subcategory where catid='$catid'";
    $r=mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            $updateURL = "updateSub.php?sub=".$row['sub_id'];
            $deleteURL = "deleteSub.php?sub=".$row['sub_id'];
            $url="product.php?subid=".$row['sub_id'];
            $img = "../subcategory/".$row['subimg'];
        ?>
       <tr>
        
            <td><?php echo $row['sub_id']; ?></td>
            <td><?php echo $row['subname']; ?></td>
            <td><img src=<?php echo $img; ?> height=100px width=100px></td>
            
            <td><a href=<?php echo $updateURL; ?>><i class="fa fa-edit" style="font-size:24px"></i></a></td>
            <td><a href=<?php echo $deleteURL; ?>><i class="fa fa-trash-o" style="font-size:24px;color:red"></i></a></td>
           <td> <a href=<?php echo $url; ?>> >> GO </a> </td>
        </tr>
        <?php
        }}
        ?>
        
    </table>

								
									</div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->


<?php

include "footer.php";
?>