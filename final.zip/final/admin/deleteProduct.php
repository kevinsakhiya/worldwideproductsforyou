<?php

include "connect.php";
$cat = $_GET['pid'];



$t = "select * from products where id='$cat'";
$y = mysqli_query($cn,$t);
if(mysqli_num_rows($y)>0)
	{
		while($row=mysqli_fetch_array($y))
		{
            $image = "../products/".$row['subimg'];
            unlink($image);
        }
    }

$q = "delete from products where id='$cat'";
$r = mysqli_query($cn,$q);

if($r){
    header('Location:index.php');
}
else{
    echo "File is not deleted";
}

?>