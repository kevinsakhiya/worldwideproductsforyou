<?php

include "connect.php";
$unm = $_POST['unm'];
$pwd = $_POST['pwd'];

$q = "insert into admin values(null,'$unm','$pwd')";
$r = mysqli_query($cn,$q);

if($r){
    header('Location:admin.php');
}else{
    echo "Admin is not added";
}

?>