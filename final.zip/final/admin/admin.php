<?php

include "header.php";
include "connect.php";

?>

<!-- /inner_content-->
<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						<div class="w3l_agileits_breadcrumbs">
							<div class="w3l_agileits_breadcrumbs_inner">
								<ul>
									<li><a href="index.php">Home</a><span>«</span></li>
									
									<li>Add Admin</li>
								</ul>
							</div>
						</div>
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Add Admin</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
								<h3 class="w3_inner_tittle two">Add Admin</h3>  
								<div class="form-body">
										<form action="admin_code.php" method="post" enctype="multipart/form-data"> 
											<div class="form-group">
												 
												<input type="text" class="form-control"  placeholder="Username" name="unm"> 
											</div>
                                            <div class="form-group">
												
												<input type="password" class="form-control"  placeholder="Password" name="pwd"> 
											</div>
											 
											  <button type="submit" name="submit" class="btn btn-default">Submit</button> 
										</form> 
                                            </div>
                                            <table id="t01">
        <tr>
            <th>Admin  ID</th>
            <th>Admin Name</th>
            <th>Admin Password</th>
            <th></th>
            
        </tr>
        <?php
    
    $q="select * from admin";
    $r=mysqli_query($cn,$q);
    if(mysqli_num_rows($r)>0)
	{
		while($row=mysqli_fetch_array($r))
		{
            
            $deleteURL = "DeleteAdmin.php?aid=".$row['id'];
            
        ?>
       <tr>
        
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['unm']; ?></td>
            <td><?php echo $row['pwd']; ?></td>
            <td><a href=<?php echo $deleteURL; ?>><i class="fa fa-trash-o" style="font-size:24px;color:red"></i></a></td>
        </tr>
        <?php
        }}
        ?>
        
    </table>
                                            </div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->

<?php

include "footer.php";

?>