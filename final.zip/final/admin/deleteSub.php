<?php

include "connect.php";
$cat = $_GET['sub'];

$q1 = "select * from products where subid='$cat'";
$r1 = mysqli_query($cn,$q1);
if(mysqli_num_rows($r1)>0)
	{
		while($row=mysqli_fetch_array($r1))
		{
            $subid = $row['id'];
            ///////// Delete product ////////////////////
            
             
             $image = "../products/".$row['image'];
             unlink($image);
             $inq = "delete from products where id='$subid'";
             $inr = mysqli_query($cn,$inq);
        }
    }


$t = "select * from subcategory where sub_id='$cat'";
$y = mysqli_query($cn,$t);
if(mysqli_num_rows($y)>0)
	{
		while($row=mysqli_fetch_array($y))
		{
            $image = "../subcategory/".$row['subimg'];
            unlink($image);
        }
    }

$q = "delete from subcategory where sub_id='$cat'";
$r = mysqli_query($cn,$q);

if($r){
    header('Location:index.php');
}
else{
    echo "File is not deleted";
}

?>