<?php

include "header.php";
include "connect.php";
$pid = $_GET['sub'];

$q = "select * from subcategory where sub_id='$pid'";
$r = mysqli_query($cn,$q);
if(mysqli_num_rows($r)>0){
    while($row=mysqli_fetch_array($r)){
        $name = $row['subname'];
        $image = "../subcategory/".$row['subimg'];
        $img = $row['subimg'];
    }
}
?>




		
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Update Sub-Category</h2>
									<!-- tables -->
									
									
								<div class="w3l-table-info agile_info_shadow">
								<h3 class="w3_inner_tittle two">Update Sub-Category </h3>  
								<div class="form-body">
										<form action="updateSub_code.php" method="post" enctype="multipart/form-data"> 
                                        <div class="form-group">
												<label for="exampleInputEmail1">Sub-Category ID</label> 
												<input type="text" class="form-control" value=<?php echo $pid; ?> placeholder="Sub-Category ID" name="pid" readonly> 
											</div>  
                                        <img src=<?php echo $image; ?> height=200 width=200><br><br>
                                         <div class="form-group">
												<label for="exampleInputEmail1">Image name</label> 
												<input type="text" class="form-control" value=<?php echo $img; ?> placeholder="Product Name" name="img" readonly> 
											</div>  
                                        <div class="form-group">
												<label for="exampleInputEmail1">Sub-Category Name</label> 
												<input type="text" class="form-control" value=<?php echo $name; ?> placeholder="Product Name" name="product"> 
											</div>
											 
											 <div class="form-group">
											  <label for="exampleInputFile">Choose Image</label> 
											  <input type="file" id="InputFile" name="InputFile"> 
											  
											  	
                                              </div> 
                                              
											  <button type="submit" name="submit" class="btn btn-default">Submit</button> 
										</form> 
											</div>
                                

								
									</div>
									
						</div>
							<!-- //tables -->
					
							<!-- /social_media-->
						
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->


<?php

include "footer.php";
?>