<?php

	session_start();
	if(!isset($_SESSION['admin_email'])){
		header('Location:login.php');
	}

?>


<!DOCTYPE html>
<html lang="zxx">
<head>
<title>Admin Pannel</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Esteem Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/component.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/export.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/flipclock.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/circles.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style_grid.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<style>
		table {
		margin-left:50px;
		margin-top:50px;
		margin-botttom:50px;
		width:80%;
		}
		th, td {
  padding: 15px;
  text-align: left;
}
		table#t01 tr:nth-child(even) {
 		 background-color: #eee;
		  padding:20px;	
		}
		table#t01 tr:nth-child(odd) {
 			background-color: #fff;
			 padding:20px;
		}
		table#t01 th {
  			background-color:blue;
  			color: white;
			  padding:20px;
		}
	</style>

</head>
<body>
<!-- banner -->
<div class="wthree_agile_admin_info">
		  <!-- /w3_agileits_top_nav-->
		  <!-- /nav-->
		  <div class="w3_agileits_top_nav">
			<ul id="gn-menu" class="gn-menu-main">
			  		 <!-- /nav_agile_w3l -->
				<li class="gn-trigger">
					<a class="gn-icon gn-icon-menu"><i class="fa fa-bars" aria-hidden="true"></i><span>Menu</span></a>
					<nav class="gn-menu-wrapper">
						<div class="gn-scroller scrollbar1">
							<ul class="gn-menu agile_menu_drop">
								<!--<li><a href="main-page.html"> <i class="fa fa-tachometer"></i> Dashboard</a></li>
								<li> <a href="about.html"><i class="fa fa-user"></i> Profile</a> </li>
								<li><a href="deal.html"><i class="fa fa-shopping-bag" aria-hidden="true"></i>Deals</a></li>	
								
								<li><a href="supplier.html"> <i class="fa fa-industry" aria-hidden="true"></i>supplier</a></li>	
								</li>
																
								<li><a href="buyer.html"><i class="fa fa-shopping-cart" aria-hidden="true"></i>Buyer</a></li>
								
								<li><a href="export.html"><i class="fa fa-arrow-circle-right" aria-hidden="true"></i>Export</a></li>
								<li><a href="import.html"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i>Import</a></li>
								
								<li><a href="feedback.html"> <i class="fa fa-comments" aria-hidden="true"></i> Feedback</a></li>
								<li class="page">
									<a href="#"><i class="fa fa-files-o" aria-hidden="true"></i> Pages <i class="fa fa-angle-down" aria-hidden="true"></i></a>
										 <ul class="gn-submenu">
						
									  <li class="mini_list_agile"> <a href="signin.html"> <i class="fa fa-caret-right" aria-hidden="true"></i> Sign In</a></li>
									   <li class="mini_list_w3"><a href="signup.html"> <i class="fa fa-caret-right" aria-hidden="true"></i> Sign Up</a></li>
									   				</ul>
								</li>-->
								<li><a href="addProduct.php"> <i class="fa fa-plus"></i> Add Products</a></li>
								<li><a href="buyer.php"> <i class="fa fa-shopping-cart"></i> Buyers</a></li>
								<li><a href="admin.php"><i class="fa fa-user"></i>Add admin</a></li>
								
					</nav>
				</li>
				<!-- //nav_agile_w3l -->
				<li class="second logo"><h1><a href="main-page.html"><i class="fa fa-graduation-cap" aria-hidden="true"></i>Worldwide Product For You</a></h1></li>
					<li class="second admin-pic">
				       <ul class="top_dp_agile">
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
												
												<h2><?php echo $_SESSION['admin_email']; ?></h2> 
												
										</a>
										<ul class="dropdown-menu drp-mnu" style="padding: left 100px; ;">
											
											
											<li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
									
						</ul>
				</li>
		
		</div>
		<div class="clearfix"></div>
		<!-- //w3_agileits_top_nav-->