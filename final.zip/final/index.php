<?php

include "header.php";

?>
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Main Slider area  ==
	====================================== -->
	<section class="main_slider">
		<div class="main_slider_area owl-carousel">
			<div class="main_slide" style="background-image:url(images/main_slide1.jpg);">	
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main_slider_table">
								<div class="main_slider_cell">
									<div class="main_slider_info">
										
										<h1>An International Buyer</h1>
										<h2>Build Your Business With Me</h2>						
										<div class="slider_contact_me btn1">
											<div class="btn1_main">			
												<a href="contact.html">contact me<i class="ion-ios-arrow-right"></i></a>
											</div>
											<div class="btn1_hover">				
												<div class="slider_contact_me btn1_info">
													<a href="contact.html"><i class="ion-ios-arrow-right"></i>contact me</a>
												</div>										
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="header_social_icons">
								<ul>
									<li><a href="#" class="ion-social-facebook active"></a></li>
									<li><a href="#" class="ion-social-skype"></a></li>
									<li><a href="#" class="ion-social-twitter active"></a></li>
									<li><a href="#" class="ion-social-googleplus-outline"></a></li>
								</ul>
							</div>
						</div>					
					</div>
				</div>			
			</div>
			<div class="main_slide " style="background-image:url(images/main_slide2.jpg);">			
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main_slider_table">
								<div class="main_slider_cell">
									<div class="main_slider_info">
										
										<h1>An International Buyer</h1>
										<h2 class="fade_effect" >Build Your Business With Me</h2>
										<div class="slider_contact_me btn1">
											<div class="btn1_main">			
												<a href="contact.html">contact me<i class="ion-ios-arrow-right"></i></a>
											</div>
											<div class="btn1_hover">				
												<div class="slider_contact_me btn1_info">
													<a href="contact.html"><i class="ion-ios-arrow-right"></i>contact me</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="header_social_icons">
								<ul>
									<li><a href="#" class="ion-social-facebook active"></a></li>
									<li><a href="#" class="ion-social-skype"></a></li>
									<li><a href="#" class="ion-social-twitter active"></a></li>
									<li><a href="#" class="ion-social-googleplus-outline"></a></li>
								</ul>
							</div>
						</div>					
					</div>
				</div>			
			</div>
		</div>		
	</section>
	<!-- ======================================
	        ==   End Main Slider area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Search area  ==
	====================================== -->
	<!--<section class="search_area">
		<div class="container">
			<div class="row">			
				<div class="col-md-12">
					<div class="search_info">
						<h1 class="txt_search" data-in-effect="bounceInUp"  data-out-effect="bounceOutDown">Search for latest trade leads from buyers & importers from all over the world</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-offset-2 col-md-8">
					<div class="search_form">					
						<form action="#" method="post">
							<div class="search_bar">
								<input type="text" placeholder="keywords">
								<i class="icon ion-edit"></i>
							</div>
							<div class="search_btn">
								<button class="srch_btn btn3">search</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>-->

	<!-- ======================================
	        ==  End Search area  ==
	====================================== -->
	<!-- ======================================
	        ==  Start About Me area  ==
	====================================== -->
	<!-- ======================================
	        ==  End About Me area  ==
	====================================== -->
	<!-- ======================================
	        ==  Start What I do area  ==
	====================================== -->
	<section class="do">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>what  i  do</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-4 ">
					<div class="services">
						<div class="service_area1  wow rotateInDownRight">
							<div class="single_services">
								<div class="service_info">
									<h2>Import</h2>
									<p>An import is a good or service bought in one country that was produced in another.</p>
								</div>
								<div class="service_image">
									<img src="images/import.png" alt="import" class="svg">
								</div>
							</div>
							<div class="single_services">
								<div class="service_info">
									<h2>Export</h2>
									<p>An export in international trade is a good or service produced in one country that is sold into another country. </p>
								</div>
								<div class="service_image">
									<img src="images/export.png" alt="export" class="svg">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-sm-offset-4">
					<div class="services">
						<div class="service_area2 wow rotateInDownLeft">
							<div class="single_services current_page_item">
								<div class="service_image">
										<img src="images/buy.png" alt="cart" class="svg">
									</div>
								<div class="service_info">
									<h2>buy</h2>
									<p>to acquire the possession of, or the right to, by paying or promising to pay an equivalent.</p>
								</div>							
							</div>
							<div class="single_services">
								<div class="service_image">
										<img src="images/sales.png" alt="sales" class="svg">
									</div>
								<div class="service_info">
									<h2>sales</h2>
									<p>Sales are activities related to selling or the number of goods or services sold in a given targeted time period.</p>
								</div>							
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        == End What I do area  ==
	====================================== -->

	<!-- ======================================
	        == Start Featured Categories area  ==
	====================================== -->
	<section class="featured_categories">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>Featured Categories</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="categories_slider owl-carousel" data-wow-duration="2s">
						<figure class="single_category">
							<a class="veno" href="images/hood.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/hood.png" alt="hood">
								<div class="icon">									
									<i class="fa fa-eye" aria-hidden="true"></i>		
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/dress.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/dress.png" alt="dress">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>		
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/shirt.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/shirt.png" alt="shirt">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>	
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/dress.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/dress.png" alt="dress">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>	
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
					</div>
				</div>
			</div>			
		</div>
	</section>
	<!-- ======================================
	        == End Featured Categories area  ==
	====================================== -->
	<!-- ======================================
	        == Start Popular Categories area  ==
	====================================== -->
	<section class="popular_categories">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>Popular Categories</h1>
					</div>
				</div>
			</div>		
			<div class="row">
				<div class="col-md-12">
					<div class="categories_slider owl-carousel" data-wow-duration="2s">
						<figure class="single_category">
							<a class="veno" href="images/bag.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/bag.png" alt="bag">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>	
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/shoes.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/shoes.png" alt="shoes">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>		
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/watch.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/watch.png" alt="watch">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>	
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
						<figure class="single_category">
							<a class="veno" href="images/shoes.png" data-gall="myGallery" data-title="Featured Categories">
								<img src="images/shoes.png" alt="shoes">
								<div class="icon">									
								<i class="fa fa-eye" aria-hidden="true"></i>		
								</div>
							</a>	
							<figcaption class="category_hover">
								<div class="category_info">									
									<h3>Style Women Dress</h3>
									<div class="category_desc">
									<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit.</p>
									</div>
								</div>
							</figcaption>							
						</figure>
					</div>
				</div>
			</div>			
		</div>
	</section>
	<!-- ======================================
	        == End Popular Categories area  ==
	====================================== -->
	<!-- ======================================
	        == Start Trusted Partners area  ==
	====================================== -->
	<section class="trusted_partners">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<h1>trusted Partners</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand11.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand11.png" alt="brand1.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true" style="padding-bottom :10px "></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand22.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand22.png" alt="brand2.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true" ></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand11.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand11.png" alt="brand1.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true"></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand22.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand22.png" alt="brand2.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true" ></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand11.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand11.png" alt="brand1.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true"></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand22.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand22.png" alt="brand2.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true"></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand11.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand11.png" alt="brand1.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true"></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="single_brand">
						<figure>
							<a class="brand_veno" href="images/brand22.png"  data-gall="myGallery" data-title="Trusted Partners">
								<img src="images/brand22.png" alt="brand2.png">
								<div class="icon1">
								<i class="fa fa-arrow-right" aria-hidden="true"></i>	
								</div>
							</a>							
							<div class="brand_hover">							
								
							</div>						
						</figure>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ======================================
	        == End Trusted Partners area  ==
	====================================== -->
	<!-- ======================================
	        == Start Questions area  ==
	====================================== -->
	<section class="question_consultation">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-0 col-sm-8">
					<div class="question_accordion wow slideInLeft">
						<div class="title_style">
							<h1>f . a . question</h1>
						</div>
						<div class="accordian_area">
							<div class="panel-group" id="accordion">
								<div class="panel panel-default">
									<a class="active" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
										<div class="panel-title">
											<p>01. How Do I Become a Distributor?</p>
											<i class="fa fa-chevron-circle-down" aria-hidden="true"></i>

										</div>
				          			</a>	    
			      					<div id="collapseOne" class="panel-collapse collapse in">
										<div class="panel_info">
											<div class="panel_image">
												<img src="images/accordion.png" alt="panel">
											</div>
											<div class="panel-body">
											Mirum est notare quam littera gothica, quam nunc putamus parum ant litterarum formas humanitatis per seacula quarta decima et quinta deceo.
										</div> 
										</div> 
			    					</div>
			      				</div>
			      				<div class="panel panel-default">
									<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
										<div class="panel-title">
											<p>02. Where Can I Buy Your Products?</p>
											<i class="fa fa-chevron-circle-down" aria-hidden="true"></i>

										</div>
				          			</a>	    
			      					<div id="collapseTwo" class="panel-collapse collapse">
										<div class="panel_info">
											<div class="panel_image">
												<img src="images/accordion.png" alt="panel">
											</div>
											<div class="panel-body">
											Mirum est notare quam littera gothica, quam nunc putamus parum ant litterarum formas humanitatis per seacula quarta decima et quinta deceo.
										</div> 
										</div> 
			    					</div>
			      				</div>
			      				<div class="panel panel-default">
									<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
										<div class="panel-title">
											<p>03. Why You Can Business With Us?</p>
											<i class="fa fa-chevron-circle-down" aria-hidden="true"></i>

										</div>
				          			</a>	    
			      					<div id="collapseThree" class="panel-collapse collapse ">
										<div class="panel_info">
											<div class="panel_image">
												<img src="images/accordion.png" alt="panel">
											</div>
											<div class="panel-body">
											Mirum est notare quam littera gothica, quam nunc putamus parum ant litterarum formas humanitatis per seacula quarta decima et quinta deceo.
										</div> 
										</div>  
			    					</div>
			      				</div>
			      				<div class="panel panel-default">
									<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
										<div class="panel-title">
											<p>04. Placerat Facer Possim Assum Bepn habent?</p>
											<i class="fa fa-chevron-circle-down" aria-hidden="true"></i>

										</div>
				          			</a>	    
			      					<div id="collapseFour" class="panel-collapse collapse">
										<div class="panel_info">
											<div class="panel_image">
												<img src="images/accordion.png" alt="panel">
											</div>
											<div class="panel-body">
											Mirum est notare quam littera gothica, quam nunc putamus parum ant litterarum formas humanitatis per seacula quarta decima et quinta deceo.
										</div> 
										</div>   
			    					</div>
			      				</div>      					
							</div>
						</div>				
					</div>
				</div>
				<div class="col-md-5 col-md-offset-1 col-sm-7">
					<div class="consultation_area wow slideInRight">					
						<div class="title_style">
							<h1>free consultation</h1>
						</div>
						<div class="consultation">
							<form action="#" method="post">
								<div class="consultation_form">
									<label for="services_option">I Would Like To Discuss</label><br>
									<div class="select">
										<select name="services_option" id="services_option" class="options">	 
										    <option value="export">Export</option>
										    <option value="import" selected>Import</option>
										    <option value="buy">Buy</option>
										    <option value="sales">Sales</option>
		  								</select>
									</div>
									<label for="name">Your Name</label><br>
									<input type="text" placeholder="Name" id="name">
									<label for="email">Your Email</label><br>
									<input type="email" placeholder="Email" id="email">
									<button type="button" class="btn_submit btn3">submit</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- ======================================
	        == End Questions area  ==
	====================================== -->
	<!-- ======================================
	        == Start Feedback area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Feedback area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Latest News area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->
	
	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

include "footer.php";

?>
