<?php

include "header.php";

?>
	<!-- ======================================
	        ==   End Header area  ==
	====================================== -->
	<!-- preloader -->
	<div id="preloader">
	    <div class="preloader-content">
	        <img src="images/preloader.gif" alt="preloader"> 
		</div>
	</div>
	<!-- ======================================
	        ==   Start Breadcrumb  area  ==
	====================================== -->
	<section class="breadcrumb">	
		<div class="container">
			<div class="supplier_title">
				<h1 class="sup_title" data-in-effect="flipInY" data-out-effect="flipOutY">Products</h1>
			</div>
			<!--<div class="row">
				<div class="col-md-12">
					<div class="supplier_country">
						<div class="country">
							<ul>
								<li><a href="index.html">Home</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">import</a>
								<i class="ion-ios-arrow-forward"></i>
								</li>
								<li><a href="#">food & beverage</a></li>
							</ul>
						</div>
						<div class="search_supplier">					
							<form action="#" method="post">
								<input type="text" placeholder="Search here...............">
								<button><i class="ion-ios-search-strong"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>-->
		</div>	
	</section>
	<!-- ======================================
	        ==   End Breadcrumb area  ==
	====================================== -->
	<!-- ======================================
	        ==   Start Export area  ==
	====================================== -->
	<section class="export">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="title_style">
						<!--<h1>Products</h1>-->
					</div>
				</div>
            </div>
            
			<div class="row">
            <?php
            $cat = $_GET['name'];
            $q = "select * from subcategory where catid='$cat'";
            $r = mysqli_query($cn,$q);
            if(mysqli_num_rows($r)>0)
			{
				while($row=mysqli_fetch_array($r))
				{
                    $img = 'subcategory/'.$row['subimg'];
                    $url = 'products3.php?sub='.$row['sub_id'];
                    
            ?>
				<a href=<?php echo $url; ?>><div class="col-sm-4 col-xs-12">
					<div class="export_item">
						<img src=<?php echo $img; ?> alt="export">
						<h2><?php echo $row['subname']; ?></h2>
					</div>
                </div></a>
                <?php
                
            }
        }else{
            
            ?>

          
                    
                    <h2>There are no products yet ....</h2>
            
            <?php
            
        }
            ?>
            </div>
            
               
			<!--<div class="row">
				<div class="pagination_list">
					<ul>
						<li><a href="#"><i class="icon ion-arrow-left-b"></i></a></li>		
						<li><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#"><i class="ion-arrow-right-c"></i></a></li>
					</ul>
				</div>
			</div>-->
		</div>
	</section>
	<!-- ======================================
	        ==   End Export area  ==
	====================================== -->
	<!-- ======================================
	        == Start Footer area  ==
	====================================== -->

	<!-- ======================================
	        == End Footer area  ==
	====================================== -->
	<!-- Scripts -->

	<!-- Jquery -->
	<script src="js/jquery-3.2.1.min.js"></script>

	<!--Bootstrap -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Wow Js -->
	<script src="js/wow.min.js"></script>

	<!-- Venobox-->
	<script src="js/venobox.min.js"></script>

	<!-- lettering js -->
	<script src="js/jquery.lettering.js"></script>

	<!-- Textillate js -->
	<script src="js/jquery.textillate.js"></script>

	<!-- Mean Menu js -->
	<script src="js/jquery.meanmenu.min.js"></script>

	<!--google map js -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Main js -->
	<script src="js/main.js"></script>
</body>
</html>
<?php

include "footer.php";

?>