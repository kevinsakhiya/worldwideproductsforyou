<?php


include "connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Title-->
	

	<!--Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,700i,900" rel="stylesheet">
	<link rel="stylesheet" href="css/lato.css">

	<!-- Favicon  -->
	<link rel="apple-touch-icon-precomposed" href="images/favicon.png">
	<link rel="shortcut icon" href="images/favicon.png" type="image/png">
    <link rel="icon" href="images/favicon.png" type="image/png">

	<!-- Bootstrap -->	
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<!-- Animate -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">

	<!-- Venobox -->
	<link rel="stylesheet" href="css/venobox.css">

	<!-- Ionicons -->
	

	<!-- Mean menu css -->
	<link rel="stylesheet" href="css/meanmenu.min.css">

	<!-- Main style sheet -->
	<link rel="stylesheet" href="style.css">
	
	
</head>
<body>
<footer>
		<section class="contact_area">
			<div class="container">
				<div class="row">
					<div class="contact_box">
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Emergency Contact</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-android-call"></i>
									</div>
									<div class="contact_info">
										<a href="#">+91 8347662588</a>								
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Location</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-location-outline"></i>
									</div>
									<div class="contact_info">
										<p>103 - Meghani Rang Bhavan, Bhakti nagar circle,Rajkot-36002</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12">
							<div class="contact">
								<div class="contact_title">
									<h1>Email</h1>
								</div>
								<div class="contact_desc">
									<div class="contact_image">
										<i class="ion-ios-email-outline"></i>
									</div>
									<div class="contact_info">
										<a href="mailto:infonews@gmail.com">worldwideproducts4you@gmail.com</a>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- footer top -->
		<div class="footer_top">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="footer_logo wow slideInLeft" >
							<div class="footer_logo_image">
								<a href="index.html"><img src="images/logo1.png" alt="logo"></a>
							</div>
							<div class="footer_logo_info">
								
							</div>						
							
						</div>					
					</div>
					<div class="col-md-2 col-sm-6">
						<div class="footer_list_link wow slideInLeft" >
							<div class="widget_title">
								<h1>quick link</h1>
							</div>
							<div class="links">
								<ul>
									<li><a href="index.php"><i class="ion-arrow-right-c"></i>Home</a></li>
                                    <li><a href="about_us.php"><i class="ion-arrow-right-c"></i>About Us</a></li>
                                    <li><a href="product.php"><i class="ion-arrow-right-c"></i>Product</a></li>
                                    <li><a href="contact.php"><i class="ion-arrow-right-c"></i>Contact</a></li>
									
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="footer_newsletter wow slideInRight">
							<div class="widget_title">
								<h1>News Subscription</h1>
							</div>
							<div class="subscribe_info">
								<p>Subscribe to our newsletter to get all our news in your inbox.</p>
							</div>
							<div class="subscribe_form">
								<form action="#" method="post">
									<input type="email" class="subscribe" placeholder="Enter your email address">
									<button class="btn_subscribe btn3">subscribe</button>
								</form>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<!-- footer bootom -->
		<div class="footer_bottom">		
			<div class="container">
				<div class="copyright">
				<p data-hover="Copyright © 2020, Design  by Iorigininfotech">Copyright © 2020, Design iorigininfotech</p>
			</div>					
			<div class="scroll btn2">
				<i class="ion-arrow-up-c"></i>
			</div>
			</div>					
		</div>
	</footer>