<?php

include "connect.php";
session_start();

$email = $_POST['login_name'];
$password = $_POST['login_password'];

$q = "select user_email from user_register where user_email='$email' and password='$password'";
$r = mysqli_query($cn,$q);
$count = mysqli_num_rows($r);

if($count > 0){
    $_SESSION['user_email'] = $email;
    header('Location:index.php');
   
}
else{
    $_SESSION['login_msg'] = "0";
    header('Location:login.php');
    
}

?>