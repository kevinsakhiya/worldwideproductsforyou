<?php
session_start();
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
include "connect.php";

$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$gender=$_POST['gender'];
$user_contact=$_POST['user_contact'];
$user_country=$_POST['user_country'];
$user_country_code=$_POST['user_country_code'];
$brand_name=$_POST['brand_name'];
$user_email=$_POST['user_email'];
$user_pwd=$_POST['user_pwd'];

//$=$_POST[''];
$qrr = "select user_email from user_register where user_email='$user_email'";
$ree = mysqli_query($cn,$qrr);
$count = mysqli_num_rows($ree);



if($count <= 0){

$target_dir = "user/";
$target_dir2 = "brand/";
$target_file = $target_dir.basename($_FILES["user_image"]["name"]);
$target_file2 = $target_dir2.basename($_FILES["brand_image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
$imgname=date('dmYHis').'.'.$imageFileType;
$imgname2=date('dmYHis').'.'.$imageFileType2;
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["user_image"]["tmp_name"]);
    $check2 = getimagesize($_FILES["brand_image"]["tmp_name"]);
    if($check !== false && $check2 !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    
    echo "Sorry, file already exists.";
    $uploadOk = 0;
    
}

if (file_exists($target_file2)) {
    
    echo "Sorry, file already exists.";
    $uploadOk = 0;
    
}
// Check file size
if ($_FILES["user_image"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

if ($_FILES["brand_image"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType2 != "jpg" && $imageFileType2 != "png" && $imageFileType2 != "jpeg"
&& $imageFileType2 != "gif") {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    
    if (move_uploaded_file($_FILES["user_image"]["tmp_name"], $target_dir.$imgname)) {

        if(move_uploaded_file($_FILES["brand_image"]["tmp_name"], $target_dir2.$imgname2)){
        $q="insert into user_register values(null,'$first_name','$last_name','$user_email','$user_pwd','$imgname','$user_contact','$gender','$user_country','$user_country_code','$imgname2','$brand_name')";
        $ca=mysqli_query($cn,$q);
        $_SESSION['register_msg'] = "1";
        header('Location:login.php');
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}
else{
    $_SESSION['register_msg'] = "0";
    header('Location:register.php');
}




?>